<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="test1" tilewidth="16" tileheight="16" tilecount="24" columns="6">
 <image source="C:/Users/Carter/Downloads/Batch_2.png" width="96" height="64"/>
</tileset>
