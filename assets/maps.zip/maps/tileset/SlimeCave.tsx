<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="SlimeCave" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="551" columns="19">
 <image source="SlimeCave.png" trans="000000" width="342" height="522"/>
</tileset>
