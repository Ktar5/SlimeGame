<?xml version="1.0" encoding="UTF-8"?>
<tileset name="GameplayTileset" tilewidth="16" tileheight="16" tilecount="32" columns="8">
 <image source="GameplayTileset.png" width="128" height="64"/>
</tileset>
