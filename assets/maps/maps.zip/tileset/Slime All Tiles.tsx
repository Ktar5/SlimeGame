<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Slime All Tiles" tilewidth="16" tileheight="16" tilecount="2394" columns="114">
 <image source="Full Tileset.png" width="1824" height="336"/>
 <terraintypes>
  <terrain name="dungeon" tile="19"/>
 </terraintypes>
 <tile id="1026" terrain=",,,0"/>
 <tile id="1027" terrain=",,0,0"/>
 <tile id="1028" terrain=",,0,0"/>
 <tile id="1029" terrain=",,0,0"/>
 <tile id="1030" terrain=",,0,"/>
 <tile id="1140" terrain=",0,,0"/>
 <tile id="1141" terrain="0,0,0,"/>
 <tile id="1142" terrain="0,0,,"/>
 <tile id="1143" terrain="0,0,,0"/>
 <tile id="1144" terrain="0,,0,"/>
 <tile id="1254" terrain=",0,,0"/>
 <tile id="1255" terrain="0,,0,"/>
 <tile id="1256" terrain="0,0,0,0"/>
 <tile id="1257" terrain=",0,,0"/>
 <tile id="1258" terrain="0,,0,"/>
 <tile id="1368" terrain=",0,,0"/>
 <tile id="1369" terrain="0,,0,0"/>
 <tile id="1370" terrain=",,0,0"/>
 <tile id="1371" terrain=",0,0,0"/>
 <tile id="1372" terrain="0,,0,"/>
 <tile id="1482" terrain=",0,,"/>
 <tile id="1483" terrain="0,0,,"/>
 <tile id="1484" terrain="0,0,,"/>
 <tile id="1485" terrain="0,0,,"/>
 <tile id="1486" terrain="0,,,"/>
</tileset>
