<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Slime All Tiles" tilewidth="16" tileheight="16" tilecount="2394" columns="114">
 <image source="Full Tileset.png" width="1824" height="336"/>
</tileset>
