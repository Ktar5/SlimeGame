<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Dungeon" tilewidth="16" tileheight="16" tilecount="551" columns="19">
 <image source="Dungeon.png" width="304" height="464"/>
</tileset>
