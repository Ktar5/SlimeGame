<?xml version="1.0" encoding="UTF-8"?>
<tileset name="GameplayImages" tilewidth="16" tileheight="16" tilecount="272" columns="17">
 <image source="GameplayImages.png" width="287" height="256"/>
</tileset>
